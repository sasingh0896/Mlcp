
import mlcp.*;
class MLCPMain
{
public static void main(String ab[])
{

//ForgotPassword ob=new ForgotPassword();
//ob.setUpForgotPassword();

LogIn ob=new LogIn();
ob.setUpLogIn();

//CreateAccountmlcp ob=new CreateAccountmlcp();
//ob.SetUpCreateAccountmlcp();

//ParkingRelease ob=new ParkingRelease();
//ob.SetUpParkingRelease();

//SearchDetail ob=new SearchDetail();
//ob.setUpSearchDetail();

//UpdateParking ob=new UpdateParking();
//ob.SetUpUpdateParking();

//ParkingRecipt ob=new ParkingRecipt();
//ob.SetUpParkingRecipt();

//TrackInfo ob=new TrackInfo();
//ob.setUpTrackInfo();

//AddLevel ob=new AddLevel();
//ob.SetUpAddLevel();

//CarRelease ob=new CarRelease();
//ob.SetUpCarRelease();

//BacktrackProcessing ob=new BacktrackProcessing();
//ob.SetUpBacktrackProcessing();

//TrackProcessing ob=new TrackProcessing();
//ob.setUpTrackProcessing();

//Parking ob=new Parking();
//ob.SetUpParking();

//ParkingMap ob=new ParkingMap();
//ob.SetUpParkingMap();

}
}